#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

'''
Este programa muestra un menu para el manejo de datos de los aprendices, con opciones como ingreso de aprendices, mostrar la lista por aprendices, 
por fichas, por evaluacion, parametrizar, eliminar aprendiz, actualizar datos del aprendiz y salir del mismo menu
'''

#Importar las librerias y archivos necesarios
import msvcrt
import sys
from os import system
from colorama import Fore, Style
from modules import  ingreso, lista_aprendices, lista_fichas, resultados, nombre, papelera

def menu():
    
    #Opciones del menu
    print(Fore.BLUE + "1 Parametrizar")
    print("2 Ingreso aprendiz")
    print("3 Lista aprendices")
    print("4 Lista por fichas")
    print("5 Resultados aprendices por ficha") 
    print("6 Borrar aprendiz")
    print("7 Actualizar datos") 
    print("0 Salir" + Style.RESET_ALL)
    
    #Menu de opciones
    respuesta = None
    while respuesta not in ["1", "2", "3", "4", "5", "6", "7", "0"]:
        respuesta = msvcrt.getwch()
        
        if respuesta == "0":
            system('cls')
            print(f"{Fore.LIGHTRED_EX} ¡Gracias por usar el programa! {Style.RESET_ALL}")   
            sys.exit()
        elif respuesta == "1":
            ingreso.lista.clear()
            system('cls')
            print("Se ha restablecido el menu correctamente")
            menu()
        elif respuesta == "2":
            ingreso.aprendices()
        elif respuesta == "3":
            lista_aprendices.listado()
        elif respuesta == "4":
            lista_fichas.fichas()
        elif respuesta == "5":
            resultados.notas()
        elif respuesta == "6":
            papelera.eliminacion()
        elif respuesta == "7":
            nombre.cambios()

#Ejecutar el proceso
if __name__ =="__main__":
    menu()