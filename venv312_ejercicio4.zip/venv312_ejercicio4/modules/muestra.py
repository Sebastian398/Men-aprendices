import msvcrt
import ej4

lista = []
def aprendices():
    
    while True:
        # Solicitar al usuario que ingrese los datos
        nombre = input("Ingrese el nombre del aprendiz: ")
        while True:
            try:
                documento = int(input("Ingrese el número de documento del aprendiz: "))
                ficha = int(input("Ingrese el número de ficha del aprendiz: "))
                break
            except ValueError:
                print("Por favor, ingrese solo valores numéricos.")
        
        print("Ingrese la evaluación del aprendiz aprobado=a desaprobado=d: ")
        evaluacion = None
        while evaluacion not in ["a", "d"]:
            evaluacion = msvcrt.getwch()
            if evaluacion == "a":
                print("El aprendiz ha aprobado")
            elif evaluacion == "d":
                print("El aprendiz no ha aprobado")
        
        aprendiz = {
            "nombre": nombre,
            "documento": documento,
            "ficha": ficha,
            "evaluacion": evaluacion
        }
        
        lista.append(aprendiz)
        
        print("¿Desea ingresar otro aprendiz? s/n")
        dato = None
        while dato not in ["s", "n"]:
            dato = msvcrt.getwch()
        if dato == "s":
            continue
        elif dato == "n":
            ej4.menu() 

if __name__ == "__main__":
    aprendices()