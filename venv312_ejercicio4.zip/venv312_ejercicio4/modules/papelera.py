#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Importar las librerias y archivos necesarios
import msvcrt
import ej4
from modules import ingreso, lista_aprendices
from os import system

'''
Este programa elimina alguno de los aprendices previamente ingresados al solicitar el numero de documento del aprendiz
'''

def eliminacion():
  while True:

    #Dejar limpio el espacio antes de ejecutar la funcion
    system('cls')
    
    #Obtener las fichas
    cursos = {}
    for aprendiz in ingreso.lista:
        salon = aprendiz.get("ficha")
        if salon in cursos:
            cursos[salon].append(aprendiz)
        else:
            cursos[salon] = [aprendiz]
    
    #Imprimir la lista de aprendices por ficha
    for salon, aprendices in cursos.items():
        print(f"Ficha: {salon}")
        for aprendiz in aprendices:
            nombre = aprendiz["nombre"]
            documento = aprendiz["documento"]
            evaluacion = aprendiz["evaluacion"]
            print(f"- Nombre: {nombre}, Documento: {documento}, Evaluación: {evaluacion}")
        print()
   
    documento = input("Ingrese el número de documento del aprendiz que desea eliminar: ")
    
    #Buscar el aprendiz por número de documento
    aprendiz_encontrado = None
    for aprendiz in ingreso.lista:
        if str(aprendiz["documento"]) == documento:
            aprendiz_encontrado = aprendiz
            break
    
    #Eliminar el aprendiz de la lista
    if aprendiz_encontrado:
        ingreso.lista.remove(aprendiz_encontrado)
        print("Aprendiz eliminado exitosamente")
        ej4.menu()
        break
    else:
        print("No se encontro ningun aprendiz con ese numero de documento")
        ej4.menu()

#Ejecutar el proceso
if __name__ =="__main__":
    ej4.menu()