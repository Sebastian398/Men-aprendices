#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Importar las librerias y archivos necesarios
from colorama import Fore, Style
from modules import ingreso
from os import system
import msvcrt
import ej4

'''
Este programa me muetra la lista de aprendices organizados por la ficha a la que pertenece cada uno
'''

def fichas():
    
    #Dejar limpio el espacio antes de ejecutar la funcion
    system('cls')
    
    #Obtener las fichas
    cursos = {}
    for aprendiz in ingreso.lista:
        salon = aprendiz.get("ficha")
        if salon in cursos:
            cursos[salon].append(aprendiz)
        else:
            cursos[salon] = [aprendiz]
    
    #Imprimir la lista de aprendices por ficha
    for salon, aprendices in cursos.items():
        print(f"Ficha: {salon}")
        for aprendiz in aprendices:
            nombre = aprendiz["nombre"]
            documento = aprendiz["documento"]
            evaluacion = aprendiz["evaluacion"]
        
            #Determina si el estudiante aprobo o no usando un color distinto en cada caso 
            if evaluacion == "a":
                    print(f"{Fore.GREEN}- Nombre: {nombre}, Documento: {documento}, Evaluación: {evaluacion}{Style.RESET_ALL}")
            elif evaluacion == "d":
                print(f"{Fore.RED}- Nombre: {nombre}, Documento: {documento}, Evaluación: {evaluacion}{Style.RESET_ALL}")
            
            print()
    
    print("Presione s para regresar al menu")
    dato = None
    while dato not in ["s"]:
        dato = msvcrt.getwch()
        if dato == "s":
            ej4.menu()

#Ejecutar el proceso        
if __name__ == "__main__":
    ej4.menu()