#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

'''
Este programa me muestra el listado de aprendices que se ingreso previamente en el archivo ingreso
'''

#Importar las librerias y archivos necesarios
from modules import ingreso
from os import system
import ej4
import msvcrt

def listado():

    #Dejar limpio el espacio antes de ejecutar la funcion 
    system('cls')
    #Mostrar la lista de diccionario de aprendices
    for aprendiz in ingreso.lista:
        print("Aprendiz:")
        for key, value in aprendiz.items():
            print(f"{key}: {value}")
        print()

    #Regresar al menu
    print("Presione s para regresar al menu")
    dato = None
    while dato not in ["s"]:
        dato = msvcrt.getwch()
        if dato == "s":
            ej4.menu()
