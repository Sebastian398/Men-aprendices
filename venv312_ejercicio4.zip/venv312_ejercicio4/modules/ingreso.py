#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

'''
Este programa me permite ingresar aprendices solicitando datos como su nombre, documento, ficha y evaluacion
'''

#Importar las librerias y archivos necesarios
import msvcrt
import ej4
from os import system

lista = []
def aprendices():
    
    #Dejar limpio el espacio antes de ejecutar la funcion 
    system('cls')
    while True:
        #Solicitar al usuario que ingrese los datos
        while True:
            nombre = input("Ingrese el nombre del aprendiz: ")
            if nombre.strip() != "":
                break
            else:
                print("Por favor, ingrese un nombre valido")
        while True:
            try:
                documento = int(input("Ingrese el numero de documento del aprendiz: "))
                ficha = int(input("Ingrese el numero de ficha del aprendiz: "))
                break
            except ValueError:
                print("Por favor, ingrese solo valores numericos")
        
        print("Ingrese la evaluacion del aprendiz aprobado=a desaprobado=d: ")
        evaluacion = None
        while evaluacion not in ["a", "d"]:
            evaluacion = msvcrt.getwch()
            if evaluacion == "a":
                print("El aprendiz ha aprobado")
            elif evaluacion == "d":
                print("El aprendiz no ha aprobado")
        
        #Diccionario para almacenar los datos del aprendiz
        aprendiz = {
            "nombre": nombre,
            "documento": documento,
            "ficha": ficha,
            "evaluacion": evaluacion
        }
        
        lista.append(aprendiz)
        
        #Regresar al menu
        print("¿Desea ingresar otro aprendiz? s/n")
        dato = None
        while dato not in ["s", "n"]:
            dato = msvcrt.getwch()
            if dato == "s":
                aprendices()
            elif dato == "n":
                ej4.menu() 