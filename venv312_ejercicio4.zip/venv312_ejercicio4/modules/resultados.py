#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Importar las librerias y archivos necesarios
from modules import ingreso, lista_fichas
from os import system
import msvcrt
import ej4
from colorama import Fore, Style

'''
Este programa muestra con color verde los datos de los aprendices que tienen la evaluacion en aprobado, y en rojo aquellos que desaprueban
'''

def notas():

    #Dejar limpio el espacio antes de ejecutar la funcion
    system('cls')
    
    #Crear un diccionario para almacenar los aprendices por ficha
    aprendices_por_ficha = {}
    
    #Organizar los datos de los aprendices por ficha
    for aprendiz in ingreso.lista:
        ficha = aprendiz["ficha"]
        if ficha not in aprendices_por_ficha:
            aprendices_por_ficha[ficha] = []
        aprendices_por_ficha[ficha].append(aprendiz)

    #Mostrar los datos de los aprendices por ficha y aplicar colores
    for ficha, aprendices in aprendices_por_ficha.items():
        print(f"Ficha: {ficha}")
        for aprendiz in aprendices:
            nombre = aprendiz["nombre"]
            documento = aprendiz["documento"]
            evaluacion = aprendiz["evaluacion"]

            #Determina si el estudiante aprobo o no usando un color distinto en cada caso 
            if evaluacion == "a":
                print(f"{Fore.GREEN}Nombre: {nombre}, Documento: {documento}, Ficha: {ficha}, Evaluación: Aprobado{Style.RESET_ALL}")
            if evaluacion == "d":
                print(f"{Fore.RED}Nombre: {nombre}, Documento: {documento}, Ficha: {ficha}, Evaluación: Desaprobado{Style.RESET_ALL}")

    print("Presione s para regresar al menu")
    dato = None
    while dato not in ["s"]:
        dato = msvcrt.getwch()
        if dato == "s":
            ej4.menu()

#Ejecutar el proceso
if __name__ =="__main__":
    ej4.menu()
