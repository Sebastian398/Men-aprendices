#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Importar las librerias y archivos necesarios
import msvcrt
import ej4
from modules import ingreso
from os import system

'''
Este programa me permite editar los datos de algun aprendiz previamente ingresado al preguntarle el documento del aprendiz
'''

def cambios():
    #Dejar limpio el espacio antes de ejecutar la funcion
    system('cls')

    #Obtener las fichas
    cursos = {}
    for aprendiz in ingreso.lista:
        salon = aprendiz.get("ficha")
        if salon in cursos:
            cursos[salon].append(aprendiz)
        else:
            cursos[salon] = [aprendiz]
    
    #Imprimir la lista de aprendices por ficha
    for salon, aprendices in cursos.items():
        print(f"Ficha: {salon}")
        for aprendiz in aprendices:
            nombre = aprendiz["nombre"]
            documento = aprendiz["documento"]
            evaluacion = aprendiz["evaluacion"]
            print(f"- Nombre: {nombre}, Documento: {documento}, Evaluación: {evaluacion}")
        print()

    # Acceder a la lista de aprendices
    listas = ingreso.lista
    print("Digite el numero de documento del aprendiz al que desea actualizar los datos: ")
    
    #Verificar si la entrada es numerica
    while True:
        dato1 = input()
        if dato1.isdigit():
            dato1 = int(dato1)
            break
        else:
            print("Por favor, ingrese solo valores numericos")
    
    #Actualizar los datos del aprendiz
    for aprendiz in listas:
        if aprendiz["documento"] == dato1:
            print("Ingrese los nuevos datos del aprendiz:")
            nombre = input("Nombre: ")
            documento = int(input("Documento: "))
            ficha = int(input("Ficha: "))
            print("Evaluacion (aprobado=a / desaprobado=d): ")
            evaluacion = None
            while evaluacion not in ["a", "d"]:
                evaluacion = msvcrt.getwch()
                if evaluacion == "a":
                    print("El aprendiz ha aprobado")
                elif evaluacion == "d":
                    print("El aprendiz no ha aprobado")

            #Actualizar los datos del aprendiz existente
            aprendiz["nombre"] = nombre
            aprendiz["documento"] = documento
            aprendiz["ficha"] = ficha
            aprendiz["evaluacion"] = evaluacion
            
            print("Los datos del aprendiz han sido actualizados")
            break
    else:
        print("El valor ingresado no esta registrado")
    
    #Regresar al menu
    print("Presione s para regresar al menu")
    dato = None
    while dato not in ["s"]:
        dato = msvcrt.getwch()
        if dato == "s":
            ej4.menu()

#Ejecutar el proceso
if __name__ =="__main__":
    ej4.menu()