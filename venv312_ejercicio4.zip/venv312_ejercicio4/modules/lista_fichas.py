#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Importar las librerias y archivos necesarios
from modules import ingreso
from os import system
import msvcrt
import ej4

'''
Este programa me muestra la lista de aprendices organizados por la ficha a la que pertenece cada uno
'''

def fichas():
    
    #Dejar limpio el espacio antes de ejecutar la funcion
    system('cls')
    
    #Obtener las fichas
    cursos = {}
    for aprendiz in ingreso.lista:
        salon = aprendiz.get("ficha")
        if salon in cursos:
            cursos[salon].append(aprendiz)
        else:
            cursos[salon] = [aprendiz]
    
    #Imprimir la lista de aprendices por ficha
    for salon, aprendices in cursos.items():
        print(f"Ficha: {salon}")
        for aprendiz in aprendices:
            nombre = aprendiz["nombre"]
            documento = aprendiz["documento"]
            evaluacion = aprendiz["evaluacion"]
            print(f"- Nombre: {nombre}, Documento: {documento}, Evaluación: {evaluacion}")
        print()
    
    print("Presione s para regresar al menu")
    dato = None
    while dato not in ["s"]:
        dato = msvcrt.getwch()
        if dato == "s":
            ej4.menu()